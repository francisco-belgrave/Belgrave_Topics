# -*- coding: utf-8 -*-

import re
import scrapy

from bs4 import BeautifulSoup

class ExpressScraper(scrapy.Spider):
    name = 'Express'
    allowed_domains = ['express.co.uk']
    start_urls = (
        'http://www.express.co.uk/news/sitemap.xml',
        'http://www.express.co.uk/showbiz/sitemap.xml',
        'http://www.express.co.uk/sport/sitemap.xml',
        'http://www.express.co.uk/comment/sitemap.xml',
        'http://www.express.co.uk/finance/sitemap.xml',
        'http://www.express.co.uk/travel/sitemap.xml',
        'http://www.express.co.uk/entertainment/sitemap.xml',
        'http://www.express.co.uk/life-style/sitemap.xml'
    )

    def start_requests(self):
        for sitemap in self.start_urls:
            yield scrapy.Request(sitemap, callback=self.parse_sitemap)

    def parse_sitemap(self, response):
        soup = BeautifulSoup(response.body_as_unicode(), 'lxml')
        for sitemap in [ x.loc.text for x in soup.findAll('sitemap') ]:
            yield scrapy.Request(sitemap, callback=self.parse_sitemap)

        year = None
        try:
            year_month = int(re.findall(r'/(\d+)\.xml$', response.url)[0])
            year = year_month / 100
        except:
            pass
        if year == 2015:
            for url in [ x.loc.text for x in soup.findAll('url') ]:
                yield scrapy.Request(url, callback=self.parse_article)

    def parse_article(self, response):
        soup = BeautifulSoup(response.body_as_unicode(), 'lxml')
        item = {}
        item['url'] = response.url
        item['article_id'] = int(re.findall(r'/(\d+)/', response.url)[0])
        try:
            tmp = soup.find('title').text.split(' | ')
            item['title'] = tmp[0]
            item['sections'] = list(reversed(tmp[1:-1]))
        except:
            pass
        try:
            item['headline'] = soup.find('meta', property='headline_short')['content'].strip()
        except:
            pass
        try:
            item['description'] = soup.find('meta', property='og:description')['content'].strip()
        except:
            pass
        try:
            item['tags'] = [ x['content'].strip() for x in soup.findAll('meta', property='article:tag') if len(x['content'].strip()) > 0]
        except:
            pass
        try:
            item['published'] = soup.find('meta', property='article:published_time')['content']
        except:
            pass
        try:
            item['modified'] = soup.find('meta', property='article:modified_time')['content']
        except:
            pass
        try:
            item['image_count'] = int(soup.find('meta', property='article:image_count')['content'])
            item['video_count'] = int(soup.find('meta', property='article:video_count')['content'])
            item['word_count'] = int(soup.find('meta', property='article:word_count')['content'])
            item['internal_link_count'] = int(soup.find('meta', property='article:internal_link_count')['content'])
            item['external_link_count'] = int(soup.find('meta', property='article:external_link_count')['content'])
        except:
            pass
        try:
            ps = [ s.findChildren() for s in soup.findAll('section', 'text-description') ]
            ps = [ x.text.strip() for p in ps for x in p if len(x.text.strip()) > 0 ]
            item['content'] = ' '.join(ps)
        except:
            pass
        return item

