#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import json
import requests

import numpy as np
import pandas as pd

from time import sleep

def get_fb_info(urls):
    req = {
        'access_token': '',  # Get one from https://developers.facebook.com/
        'include_headers': 'false',
        'batch': json.dumps([{
            'method': 'GET',
            'relative_url': '?id={}'.format(url)
        } for url in urls])
    }
    r = requests.post('https://graph.facebook.com/', req)
    return [json.loads(x['body']) for x in r.json() if x['code'] == 200]

# Download petition URLs
current_url = 'https://petition.parliament.uk/petitions.json?state=closed'
petition_urls = []
while current_url:
    tmp = requests.get(current_url).json()
    petition_urls.extend([ x['links']['self'] for x in tmp['data'] ])
    current_url = tmp['links']['next']

# Download petitions and extract information
petitions = []
for url in petition_urls:
    tmp = requests.get(url).json()['data']
    petitions.append({
        'id': tmp['id'],
        'url': 'https://petition.parliament.uk/petitions/{}'.format(tmp['id']),
        'action': tmp['attributes']['action'],
        'opened_at': tmp['attributes']['open_at'],
        'total_signatures': tmp['attributes']['signature_count'],
        'uk_signatures': next((x['signature_count']
                               for x in tmp['attributes']['signatures_by_country']
                               if x['code'] == 'GB'), None)
    })

# Convert to DataFrame
petitions = pd.DataFrame(petitions)

# Retrieve Facebook shares
fb_shares = []
for start in range(0, len(petitions), 50):
    urls = petitions['url'].iloc[start:(start+50)]
    fb_shares.extend({
            'url': x['id'],
            'fb_shares': x['share']['share_count']
        } for x in get_fb_info(urls) if 'share' in x)
    sleep(0.25)

# Convert to DataFrame and merge
fb_shares = pd.DataFrame(fb_shares)
petitions = pd.merge(petitions, fb_shares, on='url')
petitions.drop('url', axis=1, inplace=True)

petitions.to_csv('petitions.csv')

